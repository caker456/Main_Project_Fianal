import { useState } from 'react';
import { Search, Folder, File, ChevronRight, ChevronDown } from 'lucide-react';
import { OCRProgress } from './OCRProgress';
import { DocumentClassificationComplete } from './DocumentClassificationComplete';

type Step = 'select' | 'ocr' | 'complete';

interface FolderNode {
  id: string;
  name: string;
  type: 'folder' | 'file';
  children?: FolderNode[];
  path: string;
  ocrCompleted?: boolean;
  classificationCompleted?: boolean;
  category?: string;
  confidence?: number;
}

const FolderIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12.6875 3.5H7.4375L5.6875 1.75H1.3125C0.587617 1.75 0 2.33762 0 3.0625V10.9375C0 11.6624 0.587617 12.25 1.3125 12.25H12.6875C13.4124 12.25 14 11.6624 14 10.9375V4.8125C14 4.08762 13.4124 3.5 12.6875 3.5Z" fill="#F7B500"/>
  </svg>
);

const FileIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8.75 0.4375H2.625C1.89844 0.4375 1.3125 1.02344 1.3125 1.75V12.25C1.3125 12.9766 1.89844 13.5625 2.625 13.5625H11.375C12.1016 13.5625 12.6875 12.9766 12.6875 12.25V4.375L8.75 0.4375ZM11.375 12.25H2.625V1.75H8.3125V4.8125H11.375V12.25Z" fill="#999999"/>
  </svg>
);

export function DocumentClassification() {
  const [step, setStep] = useState<Step>('select');
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(['root']));
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [selectedFolders, setSelectedFolders] = useState<Set<string>>(new Set());
  const [fileStatuses, setFileStatuses] = useState<Map<string, { ocrCompleted: boolean; classificationCompleted: boolean; category?: string; confidence?: number }>>(new Map());
  const [filterOCR, setFilterOCR] = useState<'all' | 'completed' | 'pending'>('all');
  const [filterClassification, setFilterClassification] = useState<'all' | 'completed' | 'pending'>('all');

  // 샘플 폴더 구조 (실제로는 백엔드 API에서 가져와야 함)
  const folderStructure: FolderNode[] = [
    {
      id: 'root',
      name: '전체 문서',
      type: 'folder',
      path: '/',
      children: [
        {
          id: 'folder1',
          name: '금융통화위원회',
          type: 'folder',
          path: '/금융통화위원회',
          children: [
            { id: 'file1', name: '회의록_2024_01.pdf', type: 'file', path: '/금융통화위원회/회의록_2024_01.pdf' },
            { id: 'file2', name: '회의록_2024_02.pdf', type: 'file', path: '/금융통화위원회/회의록_2024_02.pdf' },
          ]
        },
        {
          id: 'folder2',
          name: '보고서',
          type: 'folder',
          path: '/보고서',
          children: [
            {
              id: 'folder2_1',
              name: '지급결제보고서',
              type: 'folder',
              path: '/보고서/지급결제보고서',
              children: [
                { id: 'file3', name: '2024_지급결제보고서.pdf', type: 'file', path: '/보고서/지급결제보고서/2024_지급결제보고서.pdf' },
                { id: 'file4', name: '2023_지급결제보고서.pdf', type: 'file', path: '/보고서/지급결제보고서/2023_지급결제보고서.pdf' },
              ]
            },
            {
              id: 'folder2_2',
              name: '금융안정보고서',
              type: 'folder',
              path: '/보고서/금융안정보고서',
              children: [
                { id: 'file5', name: '금융안정보고서_2024.pdf', type: 'file', path: '/보고서/금융안정보고서/금융안정보고서_2024.pdf' },
              ]
            },
          ]
        },
        {
          id: 'folder3',
          name: '미분류',
          type: 'folder',
          path: '/미분류',
          children: [
            { id: 'file6', name: '문서1.pdf', type: 'file', path: '/미분류/문서1.pdf' },
            { id: 'file7', name: '문서2.pdf', type: 'file', path: '/미분류/문서2.pdf' },
            { id: 'file8', name: '문서3.pdf', type: 'file', path: '/미분류/문서3.pdf' },
          ]
        },
      ]
    }
  ];

  const toggleNode = (nodeId: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(nodeId)) {
      newExpanded.delete(nodeId);
    } else {
      newExpanded.add(nodeId);
    }
    setExpandedNodes(newExpanded);
  };

  const [allFiles] = useState<Set<string>>(new Set(['file1', 'file2', 'file3', 'file4', 'file5', 'file6', 'file7', 'file8']));

  const toggleFileSelection = (fileId: string) => {
    const newSelected = new Set(selectedFiles);
    if (newSelected.has(fileId)) {
      newSelected.delete(fileId);
    } else {
      newSelected.add(fileId);
    }
    setSelectedFiles(newSelected);
  };

  const toggleFolderSelection = (folderId: string, node: FolderNode) => {
    const newSelectedFolders = new Set(selectedFolders);
    const newSelectedFiles = new Set(selectedFiles);

    if (newSelectedFolders.has(folderId)) {
      // 폴더 선택 해제
      newSelectedFolders.delete(folderId);
      // 하위 모든 파일 선택 해제
      const removeFilesRecursive = (n: FolderNode) => {
        if (n.children) {
          n.children.forEach(child => {
            if (child.type === 'file') {
              newSelectedFiles.delete(child.id);
            } else {
              removeFilesRecursive(child);
            }
          });
        }
      };
      removeFilesRecursive(node);
    } else {
      // 폴더 선택
      newSelectedFolders.add(folderId);
      // 하위 모든 파일 선택
      const addFilesRecursive = (n: FolderNode) => {
        if (n.children) {
          n.children.forEach(child => {
            if (child.type === 'file') {
              newSelectedFiles.add(child.id);
            } else {
              addFilesRecursive(child);
            }
          });
        }
      };
      addFilesRecursive(node);
    }

    setSelectedFolders(newSelectedFolders);
    setSelectedFiles(newSelectedFiles);
  };

  const renderTree = (nodes: FolderNode[], level: number = 0) => {
    return nodes.map(node => (
      <div key={node.id} style={{ marginLeft: `${level * 24}px` }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            padding: '6px 8px',
            cursor: 'pointer',
            background: selectedFiles.has(node.id) || selectedFolders.has(node.id) ? '#EEF2FF' : 'transparent',
            borderRadius: '4px',
            marginBottom: '4px'
          }}
          onClick={() => {
            if (node.type === 'folder') {
              toggleNode(node.id);
            }
          }}
        >
          {node.type === 'folder' && (
            <div
              style={{ marginRight: '4px', display: 'flex', alignItems: 'center' }}
              onClick={(e) => {
                e.stopPropagation();
                toggleNode(node.id);
              }}
            >
              {expandedNodes.has(node.id) ? (
                <ChevronDown style={{ width: '16px', height: '16px', color: '#666666' }} />
              ) : (
                <ChevronRight style={{ width: '16px', height: '16px', color: '#666666' }} />
              )}
            </div>
          )}
          {!node.type || node.type === 'folder' ? <div style={{ width: '16px', height: '16px', marginRight: '8px' }} /> : null}

          <input
            type="checkbox"
            checked={node.type === 'folder' ? selectedFolders.has(node.id) : selectedFiles.has(node.id)}
            onChange={() => {
              if (node.type === 'folder') {
                toggleFolderSelection(node.id, node);
              } else {
                toggleFileSelection(node.id);
              }
            }}
            onClick={(e) => e.stopPropagation()}
            style={{ marginRight: '8px' }}
          />

          <div style={{ marginRight: '8px' }}>
            {node.type === 'folder' ? <FolderIcon /> : <FileIcon />}
          </div>

          <span style={{ fontSize: '13px', color: '#333333' }}>
            {node.name}
          </span>
        </div>

        {node.type === 'folder' && expandedNodes.has(node.id) && node.children && (
          <div>
            {renderTree(node.children, level + 1)}
          </div>
        )}
      </div>
    ));
  };

  const handleStartClassification = () => {
    if (selectedFiles.size === 0) {
      alert('분류할 파일을 선택해주세요.');
      return;
    }
    setStep('ocr');
  };

  return (
    <div style={{ width: '1440px', minHeight: '900px', position: 'relative', background: '#F9F9F9' }}>
      {step === 'select' && (
        <div style={{ width: '1440px', height: '900px', position: 'relative' }}>
          <div style={{ width: '1440px', height: '844px', left: '0px', top: '56px', position: 'absolute' }}>
            <div style={{ width: '1384px', height: '844px', left: '56px', top: '0px', position: 'absolute', background: 'white' }}>

              {/* 헤더 */}
              <div style={{ width: '1336px', left: '24px', top: '24px', position: 'absolute' }}>
                <div style={{ color: '#666666', fontSize: '12px', fontFamily: 'Roboto', fontWeight: '600', lineHeight: '16px' }}>
                  문서 &gt; <span style={{ color: '#0070F3' }}>OCR 처리</span>
                </div>
              </div>

              {/* 설명 */}
              <div style={{ width: '1336px', left: '24px', top: '56px', position: 'absolute' }}>
                <div style={{ color: '#666666', fontSize: '11px', fontFamily: 'Roboto', fontWeight: '400', lineHeight: '14px' }}>
                  ① 좌측에서 OCR 처리할 폴더 또는 파일을 선택하세요.<br/>
                  ② 우측 테이블에서 OCR 처리 여부를 확인할 수 있습니다.<br/>
                  ③ "OCR 처리 시작" 버튼을 클릭하면 문서에서 텍스트를 추출하고 서버에 저장합니다.
                </div>
              </div>

              {/* 메인 콘텐츠 */}
              <div style={{ width: '1336px', height: '667.62px', left: '24px', top: '130.78px', position: 'absolute', borderRadius: '2px', border: '1px solid #DDDDDD' }}>

                {/* 왼쪽 패널 - 폴더/파일 트리 */}
                <div style={{ width: '600px', height: '665.62px', left: '1px', top: '1px', position: 'absolute', borderRight: '1px solid #DDDDDD', overflowY: 'auto' }}>
                  <div style={{ padding: '12px' }}>
                    <div style={{ marginBottom: '12px' }}>
                      <div style={{ color: '#333333', fontSize: '12px', fontFamily: 'Roboto', fontWeight: '600', lineHeight: '15px', marginBottom: '8px' }}>
                        폴더 및 파일 선택
                      </div>
                      <div style={{ position: 'relative' }}>
                        <input
                          type="text"
                          placeholder="검색..."
                          style={{
                            width: '100%',
                            height: '32px',
                            padding: '0 32px 0 12px',
                            border: '1px solid #CCCCCC',
                            borderRadius: '4px',
                            fontSize: '12px'
                          }}
                        />
                        <Search style={{ width: '14px', height: '14px', position: 'absolute', right: '12px', top: '9px', color: '#666666' }} />
                      </div>
                    </div>

                    {/* 트리 구조 */}
                    <div>
                      {renderTree(folderStructure)}
                    </div>
                  </div>
                </div>

                {/* 오른쪽 패널 - 파일 목록 테이블 */}
                <div style={{ width: '734px', height: '665.62px', left: '601px', top: '1px', position: 'absolute' }}>
                  {/* 헤더 및 필터 */}
                  <div style={{ height: '80px', padding: '12px', borderBottom: '1px solid #DDDDDD' }}>
                    <div style={{ marginBottom: '8px', color: '#333333', fontSize: '12px', fontFamily: 'Roboto', fontWeight: '600' }}>
                      파일 목록 ({selectedFiles.size}개 선택됨)
                    </div>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <select
                        value={filterOCR}
                        onChange={(e) => setFilterOCR(e.target.value as any)}
                        style={{ padding: '4px 8px', fontSize: '11px', border: '1px solid #CCCCCC', borderRadius: '4px' }}
                      >
                        <option value="all">OCR: 전체</option>
                        <option value="completed">OCR: 완료</option>
                        <option value="pending">OCR: 미완료</option>
                      </select>
                      <button
                        onClick={() => {
                          setFilterOCR('all');
                        }}
                        style={{ padding: '4px 12px', fontSize: '11px', border: '1px solid #CCCCCC', borderRadius: '4px', background: 'white', cursor: 'pointer' }}
                      >
                        필터 초기화
                      </button>
                    </div>
                  </div>

                  {/* 테이블 */}
                  <div style={{ height: '585px', overflowY: 'auto' }}>
                    {/* 테이블 헤더 */}
                    <div style={{ display: 'flex', background: '#F9F9F9', borderBottom: '1px solid #DDDDDD', padding: '8px', fontSize: '11px', fontWeight: '700', position: 'sticky', top: 0, zIndex: 1 }}>
                      <div style={{ width: '30px', textAlign: 'center' }}>
                        <input type="checkbox" />
                      </div>
                      <div style={{ flex: 1 }}>파일명</div>
                      <div style={{ width: '100px', textAlign: 'center' }}>OCR 상태</div>
                      <div style={{ width: '150px', textAlign: 'center' }}>등록일</div>
                    </div>

                    {/* 테이블 내용 */}
                    {Array.from(allFiles).map((fileId, index) => {
                      const fileName = `문서${index + 1}.pdf`;
                      const status = fileStatuses.get(fileId) || { ocrCompleted: false, classificationCompleted: false };

                      // 필터 적용
                      if (filterOCR === 'completed' && !status.ocrCompleted) return null;
                      if (filterOCR === 'pending' && status.ocrCompleted) return null;

                      return (
                        <div
                          key={fileId}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            padding: '8px',
                            borderBottom: '1px solid #F3F3F3',
                            fontSize: '11px'
                          }}
                        >
                          <div style={{ width: '30px', textAlign: 'center' }}>
                            <input
                              type="checkbox"
                              checked={selectedFiles.has(fileId)}
                              onChange={() => toggleFileSelection(fileId)}
                            />
                          </div>
                          <div style={{ flex: 1, color: '#333333', display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <FileIcon />
                            {fileName}
                          </div>
                          <div style={{ width: '100px', textAlign: 'center' }}>
                            {status.ocrCompleted ? (
                              <span style={{ color: '#10B981', fontSize: '10px' }}>✓ 완료</span>
                            ) : (
                              <span style={{ color: '#999999', fontSize: '10px' }}>미완료</span>
                            )}
                          </div>
                          <div style={{ width: '150px', textAlign: 'center', fontSize: '10px', color: '#666666' }}>
                            2024-10-24 14:32:15
                          </div>
                        </div>
                      );
                    })}

                    {allFiles.size === 0 && (
                      <div style={{ textAlign: 'center', padding: '60px 20px', color: '#999999', fontSize: '12px' }}>
                        파일이 없습니다
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* 하단 버튼 */}
              <div style={{ width: '1336px', height: '39.59px', left: '24px', top: '806.41px', position: 'absolute', background: '#111111', borderRadius: '2px' }}>
                <div style={{ left: '16px', top: '11.79px', position: 'absolute', color: 'white', fontSize: '13px', fontFamily: 'Roboto', fontWeight: '400', lineHeight: '16px' }}>
                  선택된 파일에서 텍스트를 추출하고 서버에 저장합니다.
                </div>

                <div
                  onClick={handleStartClassification}
                  style={{
                    width: '126.34px',
                    height: '23.59px',
                    left: '1190px',
                    top: '8px',
                    position: 'absolute',
                    background: selectedFiles.size > 0 ? '#2F4F8A' : '#666666',
                    borderRadius: '2px',
                    cursor: selectedFiles.size > 0 ? 'pointer' : 'not-allowed',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  <div style={{ color: 'white', fontSize: '12px', fontFamily: 'Roboto', fontWeight: '400', lineHeight: '15px' }}>
                    OCR 처리 시작
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {step === 'ocr' && (
        <OCRProgress
          totalFiles={selectedFiles.size}
          onCancel={() => setStep('select')}
          onComplete={() => setStep('complete')}
        />
      )}

      {step === 'complete' && (
        <DocumentClassificationComplete
          totalFiles={selectedFiles.size}
          onConfirm={() => setStep('select')}
        />
      )}
    </div>
  );
}
